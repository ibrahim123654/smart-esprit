#include <gtk/gtk.h>


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretour_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_hom_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_fem_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_aff_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_rech_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_supr_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview2_mod_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_affmod_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_retourmod_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_e1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_e2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_e3_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_e4_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_boutton2_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_hom_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_fem_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button3_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_rechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_rech_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_chercher_etage_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_niveau_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_retour_supp_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_aff_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_retourajout_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_Totalniveau_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonR_retourchercher_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1R_retourwtach2_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2R_retouraffrech_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_rechniv_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_calcul_etage_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton5R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton7R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton8R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_deconexion_raouf_clicked     (GtkButton       *button,
                                        gpointer         user_data);

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "heberg.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"



/////var global
int x,y;
int z,w,R;

char so[200];


void
on_radiobutton_hom_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=0;}
}


void
on_radiobutton_fem_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}

/////////////boutton ajouter////////////////
void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
hebergement g;
GtkWidget *windowajout, *windowaff,*nom,*pre,*cin,*nmtel,*adr,*mail,*jour,*mois,*annee,*sexe,*numdechambre,*niv,*spec;
windowajout=create_fenetre_ajout();
nom = lookup_widget(button,"entry1_nom");
pre = lookup_widget(button,"entry1_prenom");
cin = lookup_widget(button,"entry1_cin");
nmtel=lookup_widget(button,"entry1_nmtel");
adr=lookup_widget(button,"entry1_adresse");
mail=lookup_widget(button,"entry1_email");
numdechambre=lookup_widget(button,"entrynumdechambre");
jour = lookup_widget(button,"spinbutton1_jour");
mois = lookup_widget(button,"spinbutton1_mois");
annee = lookup_widget(button,"spinbutton1_annee");
niv=lookup_widget(button,"raoufcomboboxentry1");
spec=lookup_widget(button,"raoufcomboboxentry2");
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(g.prenom,gtk_entry_get_text(GTK_ENTRY(pre)));
strcpy(g.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(g.numerotel,gtk_entry_get_text(GTK_ENTRY(nmtel)));
strcpy(g.adresse,gtk_entry_get_text(GTK_ENTRY(adr)));
strcpy(g.email,gtk_entry_get_text(GTK_ENTRY(mail)));
strcpy(g.numcha,gtk_entry_get_text(GTK_ENTRY(numdechambre)));
strcpy(g.niv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(niv)));
strcpy(g.spec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(spec)));
g.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
g.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
g.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
if(x==1)
{strcpy(g.sexe,"femme");} 
else
{strcpy(g.sexe,"homme");}
if (y==4)
{strcpy(g.etage,"4");} 
else if (y==3)
{strcpy(g.etage,"3");}
else if (y==2)
{strcpy(g.etage,"2");}
else 
{strcpy(g.etage,"1");}
ajouterhebergement(g);
x=0;
y=0;

windowajout=lookup_widget(button,"fenetre_ajout");
gtk_widget_destroy(windowajout);
windowaff=create_fenetre_afficher();
gtk_widget_show(windowaff);
}



void
on_button1_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview1_aff_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

/////////////boutton rech fenetre d'affichage///////////////////
void
on_button2_rech_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrechercher,*windowaff;
windowaff=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(windowaff);
windowrechercher=create_heber_rech();
gtk_widget_show(windowrechercher);
}

/////////////boutton ajout fenetre d'affichage///////////////////
void
on_button2_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout,*windowaff;
windowaff=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(windowaff);
windowajout=create_fenetre_ajout();
gtk_widget_show(windowajout);
}

/////////////boutton modifier fenetre d'affichage///////////////////
void
on_button2_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmodif, *windowaff;
windowaff=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(windowaff);
windowmodif=create_window_modifier();
gtk_widget_show (windowmodif);
}

/////////////boutton supp fenetre d'affichage///////////////////
void
on_button2_supr_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowsupp,*windowaff;
windowaff=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(windowaff);
windowsupp=create_heber_sup();
gtk_widget_show (windowsupp);
}

/////////////affichage de tree////////////////////////
void
on_button2_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowafficher;
windowafficher=lookup_widget(button,"fenetre_afficher");
tree=lookup_widget(windowafficher,"treeview1_aff");
windowafficher=create_fenetre_afficher();
gtk_widget_show(windowafficher);
gtk_widget_destroy(windowafficher);

afficherhebergement (tree);


}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=3;}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=2;}
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=1;}
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=4;}
}


void
on_treeview2_mod_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button2_affmod_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////retour modifier///////////////////////
void
on_button2_retourmod_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmodif, *windowafficher;
windowmodif=lookup_widget(button,"window_modifier");
gtk_widget_destroy(windowmodif);
windowafficher=create_fenetre_afficher();
gtk_widget_show (windowafficher);
}


void
on_checkbutton2_e1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{w=1;}
}


void
on_checkbutton2_e2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{w=2;}
}


void
on_checkbutton2_e3_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{w=3;}
}


void
on_checkbutton2_e4_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{w=4;}
}

/////////////////Fonction modifier////////////////////
void
on_boutton2_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
hebergement g1;
GtkWidget *windowmodif, *windowafficher, *nom1,*pre1,*cin1,*nmtel1,*adr1,*mail1,*jour1,*mois1,*annee1,*sexe1,*numdechambre1,*niv1,*spec1;
nom1 = lookup_widget(button,"entry2_nom");
pre1 = lookup_widget(button,"entry2_prenom");
cin1 = lookup_widget(button,"entry2_cin");
nmtel1=lookup_widget(button,"entry2_numtel");
adr1=lookup_widget(button,"entry2_adresse");
mail1=lookup_widget(button,"entry2_email");
numdechambre1=lookup_widget(button,"entry2_numchamb");
jour1 = lookup_widget(button,"spinbutton2_jour");
mois1 = lookup_widget(button,"spinbutton2_mois");
annee1 = lookup_widget(button,"spinbutton2_annee");
niv1=lookup_widget(button,"raoufcomboboxentry3");
spec1=lookup_widget(button,"raoufcomboboxentry4");
strcpy(g1.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(g1.prenom,gtk_entry_get_text(GTK_ENTRY(pre1)));
strcpy(g1.cin,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(g1.numerotel,gtk_entry_get_text(GTK_ENTRY(nmtel1)));
strcpy(g1.adresse,gtk_entry_get_text(GTK_ENTRY(adr1)));
strcpy(g1.email,gtk_entry_get_text(GTK_ENTRY(mail1)));
strcpy(g1.numcha,gtk_entry_get_text(GTK_ENTRY(numdechambre1)));
strcpy(g1.niv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(niv1)));
strcpy(g1.spec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(spec1)));
g1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
g1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
g1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
if(z==1)
{strcpy(g1.sexe,"femme");} 
else
{strcpy(g1.sexe,"homme");}
if (w==4)
{strcpy(g1.etage,"4");} 
else if (w==3)
{strcpy(g1.etage,"3");}
else if (w==2)
{strcpy(g1.etage,"2");}
else 
{strcpy(g1.etage,"1");}
modifierhebergement(g1);
z=0;
w=0;
windowmodif=lookup_widget(button,"window_modifier");
gtk_widget_destroy(windowmodif);
windowafficher=create_fenetre_afficher();
gtk_widget_show (windowafficher);
}


void
on_radiobutton2_hom_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=0;}
}


void
on_radiobutton2_fem_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=1;}
}

//////////////bouton supprimer///////////////
void
on_button3_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
char cin[20];
char text[20];
char text3[20];
int ce;
GtkWidget *windowsup, *windowaff, *iden;
GtkWidget *outputMsg2;
GtkWidget *outputMsg3;
iden = lookup_widget(button,"entry4_cin");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(iden)));
ce=rechercherhebergement(cin);
if (ce==0)
	{
	strcpy(text,"Cin n'existe pas");
        outputMsg2=lookup_widget(button,"label74"); 
        gtk_label_set_text(GTK_LABEL(outputMsg2),text);	
	}
else {	
supprimerhebergement(cin);

strcpy(text3,"Operation terminer");
outputMsg3=lookup_widget(button,"label75"); 
gtk_label_set_text(GTK_LABEL(outputMsg3),text3);


}
}

////////////////chercher////////////////////
void
on_button3_rechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
char cin[20];
char text[20];
GtkWidget *ci, *rech,*oui,*non;
GtkWidget *tree;
GtkWidget *windowrechercher;
GtkWidget *outputMsg1;

int ce;
windowrechercher=lookup_widget(button,"heber_rech");
oui=create_heber_affrech();
ci = lookup_widget(button,"entry4_rech");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ci)));
ce=rechercherhebergement(cin);
if (ce==0)
	{
	strcpy(text,"Cin n'existe pas");
        outputMsg1=lookup_widget(button,"label73"); 
        gtk_label_set_text(GTK_LABEL(outputMsg1),text);	
	}
if (ce==1)	
	{	

gtk_widget_destroy(windowrechercher);
tree=lookup_widget(oui,"treeview3_rech");

affichage_hebergement_rechercher(tree);
gtk_widget_show(oui);
}		
}


void
on_treeview3_rech_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}



void
on_button_niveau_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_retour_supp_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowsup, *windowaff;

windowsup=lookup_widget(button,"heber_sup");
gtk_widget_destroy(windowsup);
windowaff=create_fenetre_afficher();
gtk_widget_show(windowaff);

////windowsupp=lookup_widget(button,"window_supprimer");
////gtk_widget_destroy(windowsupp);
///windowafficher=create_fenetre_afficher();
///gtk_widget_show (windowafficher);

}





void
on_button1_retourajout_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout, *windowaff;
windowajout=lookup_widget(button,"fenetre_ajout");
gtk_widget_destroy(windowajout);
windowaff=create_fenetre_afficher();
gtk_widget_show (windowaff);
}

///////////bouton vers window tache2/////////////////
void
on_button1_Totalniveau_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkCalendar *ajc;
GtkWidget *windowaff,*windowniv;
hebergement g;
guint day,month,year;
ajc=lookup_widget(objet,"ajc");
gtk_calendar_get_date(GTK_CALENDAR(ajc),&day,&month,&year);
g.date.jour=year;
g.date.mois=month+1;
g.date.annee=day;

windowaff=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(windowaff);
windowniv=create_nbr_de_niveau();
gtk_widget_show(windowniv);

}
//////////bouton retour chercher/////////////////////
void
on_buttonR_retourchercher_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrech, *windowaff;
windowrech=lookup_widget(button,"heber_rech");
gtk_widget_destroy(windowrech);
windowaff=create_fenetre_afficher();
gtk_widget_show (windowaff);
}

/////////////// retour window tache2/////////////////
void
on_button1R_retourwtach2_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowtache2, *windowaff;
windowtache2=lookup_widget(button,"nbr de niveau");
gtk_widget_destroy(windowtache2);
windowaff=create_fenetre_afficher();
gtk_widget_show (windowaff);
}

/////////////retour window affichage de chercher//////
void
on_button2R_retouraffrech_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaffrech, *windowaff;
windowaffrech=lookup_widget(button,"heber_affrech");
gtk_widget_destroy(windowaffrech);
windowaff=create_fenetre_afficher();
gtk_widget_show (windowaff);
}








void
on_checkbutton5R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{R=1;}
}





void
on_checkbutton6R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{R=2;}
}



void
on_checkbutton7R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{R=3;}
}


void
on_checkbutton8R_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{R=4;}
}

void
on_button_calcul_etage_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
char etage[100];
GtkWidget *somme;
int sum;
if(R=1)
{
somme = lookup_widget(button, "label66") ;
sum=niveau(etage);
sprintf(so,"%d",sum);
gtk_label_set_text(GTK_LABEL(somme),so);
}
if(R=2)
{
somme = lookup_widget(button, "label66") ;
sum=niveau(etage);
sprintf(so,"%d",sum);
gtk_label_set_text(GTK_LABEL(somme),so);
}
}
//////////////deconexion vers home/////////////////
void
on_button_deconexion_raouf_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


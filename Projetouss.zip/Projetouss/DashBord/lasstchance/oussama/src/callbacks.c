#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "fonction.c"
#include <stdlib.h>
#include <string.h>


void
on_ajouter1_clicked                   ( GtkWidget      *button,
                                        gpointer         user_data)
{   GtkWidget* fenetre_ajout;
     GtkWidget* fenetre_princ;
fenetre_ajout=lookup_widget (button,"window2");
fenetre_ajout=create_window2 ();
gtk_widget_show(fenetre_ajout);
afficher_capteur(fenetre_ajout);
fenetre_princ=lookup_widget (button,"window1");
gtk_widget_destroy(fenetre_princ);
   
   

}


///////////////////////////////////////////////////////////////////////

void
on_modifier1_clicked                   ( GtkWidget      *button,
                                        gpointer         user_data)
{ GtkWidget *fenetre_mod;
    GtkWidget *fenetre_princ;
fenetre_mod=lookup_widget (button,"window2");
fenetre_mod=create_window2 ();
gtk_widget_show(fenetre_mod);
afficher_capteur(fenetre_mod);
fenetre_princ=lookup_widget (button,"window1");
gtk_widget_destroy(fenetre_princ);

}

////////////////////////////////////////////////////////////////////////
void
on_supprimer1_clicked                  ( GtkWidget      *button,
                                        gpointer         user_data)
{  GtkWidget *fenetre_supp;
    GtkWidget *fenetre_princ;
fenetre_supp=lookup_widget (button,"window3");
fenetre_supp=create_window3();
gtk_widget_show(fenetre_supp);
afficher_capteur(fenetre_supp);
fenetre_princ=lookup_widget (button,"window1");
gtk_widget_destroy(fenetre_princ);

}

////////////////////////////////////////////////////////////////////////////
void
on_consulter_clicked                  ( GtkWidget      *button,
                                        gpointer         user_data)
{ GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
  GtkWidget *fenetre_princ;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(button,"window1");

gtk_widget_destroy(fenetre_ajout);
fenetre_afficher=lookup_widget(button,"window4");
fenetre_afficher=create_window4();

gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);
fenetre_princ=lookup_widget (button,"window1");
gtk_widget_destroy(fenetre_princ);

}

///////////////////////////////////////////////////////////////////////////////////
int x;
int a;
void
on_ajout_clicked                        (GtkWidget      *button,
                                        gpointer         user_data)
{  capteur C;
   GtkWidget *IdentifianteCapt;
   GtkWidget *MarqueCapt;
   GtkWidget *TypeCapt;
   GtkWidget *JourCapt;
   GtkWidget *MoisCapt;
   GtkWidget *AnneeCapt;
   GtkWidget *ComboboxValeurMini;
   GtkWidget *ComboboxValeurMaxi;
   GtkWidget *ComboboxZoCov;
   GtkWidget *outputMsg;
   int ajout,verif;
   char text[200];
  
  
  
GtkWidget *fenetre_ajout;

fenetre_ajout=lookup_widget(button,"window2");
IdentifianteCapt=lookup_widget(button,"entry_id");
MarqueCapt=lookup_widget(button,"entry_mq");
strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(IdentifianteCapt)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(MarqueCapt)));
/////////////////////////////////////////////////////////
JourCapt=lookup_widget(button,"spinbutton1");
MoisCapt=lookup_widget(button,"spinbutton2");
AnneeCapt=lookup_widget(button,"spinbutton3");
C.JourCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JourCapt));
C.MoisCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MoisCapt));
C.AnneeCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AnneeCapt));
///////////////////////////////////////////////////////////
ComboboxValeurMaxi=lookup_widget(button,"combobox_max");
ComboboxValeurMini=lookup_widget(button,"combobox_min");
ComboboxZoCov=lookup_widget(button,"combobox7");
strcpy(C.captValMin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMini)));
strcpy(C.captValMax,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMaxi)));
strcpy(C.captZone,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxZoCov)));
///////////////////////////////////////////////////////////////////////////
if(x==1)
{strcpy(C.captType,"Fumee");}
else
if(x==2)
{strcpy(C.captType,"Mouvement");}
       
//ajout=ajouter_capt(C);

verif=exist_capteur(C.captID);

switch(verif)
    
{
    case 0:  
    { ajout=ajouter_capt(C); 
     strcpy (text,"Ajout Réussi");
     outputMsg=lookup_widget(button,("Msg"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;
    case 1:
    { strcpy (text,"Identifiant déja existe");
    outputMsg=lookup_widget(button,("Msg"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
}
 }
//////////////////////////////////////////////////////////////////////
void
on_modif_clicked                      (GtkWidget      *button,
                                        gpointer         user_data)
{   capteur C;
   GtkWidget *IdentifianteCapt;
   GtkWidget *MarqueCapt;
   GtkWidget *TypeCapt;
   GtkWidget *JourCapt;
   GtkWidget *MoisCapt;
   GtkWidget *AnneeCapt;
   GtkWidget *ComboboxValeurMini;
   GtkWidget *ComboboxValeurMaxi;
   GtkWidget *ComboboxZoCov;
   GtkWidget *outputMsg;
   int mod,verif;
   char text[200];
  
   
GtkWidget *fenetre_ajout;

fenetre_ajout=lookup_widget(button,"window2");
IdentifianteCapt=lookup_widget(button,"entry_id");
MarqueCapt=lookup_widget(button,"entry_mq");
strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(IdentifianteCapt)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(MarqueCapt)));
/////////////////////////////////////////////////////////
JourCapt=lookup_widget(button,"spinbutton1");
MoisCapt=lookup_widget(button,"spinbutton2");
AnneeCapt=lookup_widget(button,"spinbutton3");
C.JourCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JourCapt));
C.MoisCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MoisCapt));
C.AnneeCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AnneeCapt));
///////////////////////////////////////////////////////////
ComboboxValeurMaxi=lookup_widget(button,"combobox_max");
ComboboxValeurMini=lookup_widget(button,"combobox_min");
ComboboxZoCov=lookup_widget(button,"combobox7");
strcpy(C.captValMin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMini)));
strcpy(C.captValMax,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMaxi)));
strcpy(C.captZone,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxZoCov)));
///////////////////////////////////////////////////////////////////////////
if(x==1)
{strcpy(C.captType,"Fumee");}
else
if(x==2)
{strcpy(C.captType,"Mouvement");}
 // mod=modifier_capt(C); 
verif=exist_capteur(C.captID);

switch(verif)
    
{
    case 0:  
    { strcpy (text,"Identifiant n'existe pas");
    outputMsg=lookup_widget(button,("Msg"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
    case 1:
   
    {  mod=modifier_capt(C);
     strcpy (text,"Modifie Réussi");
     outputMsg=lookup_widget(button,("Msg"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break; 
    break;
} 

}
///////////////////////////////////////////////////////////////////////////////////////

void
on_button_affich1_clicked               ( GtkWidget      *button,
                                        gpointer         user_data)
{  GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(button,"window2");

gtk_widget_destroy(fenetre_ajout);
fenetre_afficher=lookup_widget(button,"window4");
fenetre_afficher=create_window4();

gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

gtk_widget_destroy(fenetre_ajout);

}

////////////////////////////////////////////////////////////////////////////////
void
on_button7_ret_clicked                ( GtkWidget      *button,
                                        gpointer         user_data)
{ GtkWidget *fenetre_principale, *fenetre_ajout_modif;
fenetre_ajout_modif=lookup_widget(button,"window2");
fenetre_principale=lookup_widget(button,"window1");

gtk_widget_destroy(fenetre_ajout_modif);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);

}

int conf=0;
int *r=&conf;
void
on_supp_clicked                      ( GtkWidget      *button,
                                        gpointer         user_data)
{    GtkWidget *input1;
          
     GtkWidget  *fenetre_supp;
     GtkWidget *outputMsg;
     int supp,verif;
     char text[200];
    char ID[20];
     

fenetre_supp=lookup_widget(button,"window3");
input1=lookup_widget(button,"entry_supp");   
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(input1)));
if(conf)
//supp=supprimer_capt(ID);

{verif=exist_capteur(ID);


switch(verif)
    
{
    case 0:
   
     
    { strcpy (text,"Identifiant à supprimer n'existe pas");
    outputMsg=lookup_widget(button,("label51"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
  
    break;
    case 1:
     
     {
      supp=supprimer_capt(ID);
     strcpy (text,"Suppression Réussi");
     outputMsg=lookup_widget(button,("label53"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    
    break; 
    break;
}
}
else 
{strcpy (text,"La confirmation est obligatoire!");
    outputMsg=lookup_widget(button,("label52"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
}

/////////////////////////////////////////////////////////////////////////////////////
void
on_button10_affich_clicked             ( GtkWidget      *button,
                                        gpointer         user_data)
{  GtkWidget *fenetre_supp;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_afficher=lookup_widget(button,"window4");
fenetre_afficher=create_window4();

gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);
fenetre_supp=lookup_widget(button,"window3");
gtk_widget_destroy(fenetre_supp);


}

//////////////////////////////////////////////////////////////////////////////////
void
on_button9_ret_clicked                  ( GtkWidget      *button,
                                        gpointer         user_data)
{  GtkWidget *fenetre_principale, *fenetre_ajout_supp;
fenetre_ajout_supp=lookup_widget(button,"window3");
fenetre_principale=lookup_widget(button,"window1");

gtk_widget_destroy(fenetre_ajout_supp);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);

}

//////////////////////////////////////////////////////////////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{  
GtkTreeIter iter;
gchar* identi;
gchar* marque;
gchar* typ;
gchar* jourr;
gchar* moiss;
gchar* anneee;
gchar* valmin;
gchar* valmax;
gchar* zone;
capteur c;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* window_modif,*windowaff,*tre,*idt,*m,*ty,*jjj,*mmm,*aaa,*vmi,*vmx,*zo;

if (gtk_tree_model_get_iter(model, &iter,path))
{


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&identi,1,&marque,2,&typ,3,&jourr,4,&moiss,5,&anneee,6,&valmin,7,&valmax,8,&zone,-1);

windowaff=create_window4();
window_modif=create_window2();
gtk_widget_hide(windowaff);

gtk_widget_show(window_modif);

idt=lookup_widget(window_modif,"entry_id");
gtk_entry_set_text(GTK_ENTRY(idt),identi);

m=lookup_widget(window_modif,"entry_mq");
gtk_entry_set_text(GTK_ENTRY(m),marque);




}
}
///////////////////////////////////////////////////////////////////////////////////////////
void
on_recherche_clicked                    ( GtkWidget      *button,
                                        gpointer         user_data)
{
 GtkWidget *Fenetrerech;
   GtkWidget *idy;
   GtkWidget *treeviewrech;
      GtkWidget *outputMsg;
   int verif;
    char text[200];
   char id[20];
   
Fenetrerech=lookup_widget(button,"window4");
idy=lookup_widget(button,"entry_rech");
treeviewrech=lookup_widget(button,"treeview2_rech");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idy)));
verif=exist_capteur(id);

switch(verif)
    
{
    case 0:  
    { strcpy (text,"Identifiant n'existe pas");
    outputMsg=lookup_widget(button,("label64"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
    case 1:
   
    {  rechercher_capteur(treeviewrech, id);
       remove(treeviewrech);
       strcpy (text,"Identifiant existe");
       outputMsg=lookup_widget(button,("label64"));
       gtk_label_set_text(GTK_LABEL(outputMsg),text);
      }
    break; 
    break;
} 

}


///////////////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}

//////////////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}

//////////////////////////////////////////////////////////////////////////////////////////////

void
on_button7_clicked                      (GtkWidget      *button,
                                        gpointer         user_data)
{  GtkWidget *fenetre_principale, *fenetre_aff;
fenetre_aff=lookup_widget(button,"window4");
fenetre_principale=lookup_widget(button,"window1");

gtk_widget_destroy(fenetre_aff);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);

}
//////////////////////////////////////////////////////////////////////////////////////////////

void
on_treeview2_rech_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
  

}

/////////////////////////////////////////////////////////////////////////////////////////////
void
on_button8_actu_clicked                  (GtkWidget      *button,
                                        gpointer         user_data)
{GtkWidget  *fenetre_aff,*treeview;
fenetre_aff=create_window4();
gtk_widget_show(fenetre_aff);
treeview=lookup_widget(fenetre_aff,"treeview1");
afficher_capteur(treeview);

fenetre_aff=lookup_widget(button,"window4");

gtk_widget_destroy(fenetre_aff);

}
//////////////////////////////////////////////////////////////////////////////////////////////

void
on_button8_al_clicked                  (GtkWidget      *button,
                                        gpointer         user_data)
{
  GtkWidget *fenetre_al;
  GtkWidget *fenetre_princ;
GtkWidget *tree;
GtkWidget *tree1;
fenetre_al=lookup_widget (button,"window5");
fenetre_al=create_window5 ();
gtk_widget_show(fenetre_al);
tree1=lookup_widget(fenetre_al,"treeview2");
afficher_alarme(tree1);
tree1=lookup_widget(fenetre_al,"treeview3");
afficher_alarme1(tree1);
fenetre_princ=lookup_widget (button,"window1");
gtk_widget_destroy(fenetre_princ);

}

//////////////////////////////////////////////////////////////////////////////////////////////
void
on_button9_tm_clicked                  (GtkWidget      *button,
                                        gpointer         user_data)
{
  
}

/////////////////////////////////////////////////////////////////////////////////////////////

void
on_button10_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{   

}
////////////////////////////////////////////////////////////////////////////////////////////

void
on_button11_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{ 
GtkWidget *fenetre_principale, *fenetre_ajout_supp;
fenetre_ajout_supp=lookup_widget(button,"window5");
fenetre_principale=lookup_widget(button,"window1");

gtk_widget_destroy(fenetre_ajout_supp);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);
}
///////////////////////////////////////////////////////////////////////////////////////////

void
on_checkbutton_conf_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
*r=1;
else
*r=0;
}
/////////////////////////////////////////////////////////////////////////////////////////
void
on_button12_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget  *fenetre_aff;
fenetre_aff=create_window3();
gtk_widget_show(fenetre_aff);

afficher_capteur(fenetre_aff);

fenetre_aff=lookup_widget(button,"window3");

gtk_widget_destroy(fenetre_aff);

}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}




void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* fenetre_al;
     GtkWidget* fenetre_princ;
fenetre_princ=lookup_widget (button,"window1");
fenetre_princ=create_window1 ();
gtk_widget_show(fenetre_princ);
fenetre_al=lookup_widget (button,"window5");
gtk_widget_destroy(fenetre_al);
   
}


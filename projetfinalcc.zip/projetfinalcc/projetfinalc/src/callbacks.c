#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "utilisateur.h"
#include "support.h"

int x,y,z;
void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion1;
windowbienvenue=lookup_widget(button,"window_bienvenue");
gtk_widget_destroy(windowbienvenue);
windowconnexion1=create_window_connexion1();
gtk_widget_show(windowconnexion1);
}


void
on_button_nutrition_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion2;
windowbienvenue=lookup_widget(button,"window_bienvenue");
gtk_widget_destroy(windowbienvenue);
windowconnexion2=create_window_connexion2();
gtk_widget_show(windowconnexion2);
}


void
on_button_foyer_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion3;
windowbienvenue=lookup_widget(button,"window_bienvenue");
gtk_widget_destroy(windowbienvenue);
windowconnexion3=create_window_connexion3();
gtk_widget_show(windowconnexion3);
}


void
on_button_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion4;
windowbienvenue=lookup_widget(button,"window_bienvenue");
gtk_widget_destroy(windowbienvenue);
windowconnexion4=create_window_connexion4();
gtk_widget_show(windowconnexion4);
}


void
on_button_reclamation_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion5;
windowbienvenue=lookup_widget(button,"window_bienvenue");
gtk_widget_destroy(windowbienvenue);
windowconnexion5=create_window_connexion5();
gtk_widget_show(windowconnexion5);
}


void
on_button_alarme_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion6;
windowbienvenue=lookup_widget(button,"window_bienvenue");
gtk_widget_destroy(windowbienvenue);
windowconnexion6=create_window_connexion6();
gtk_widget_show(windowconnexion6);
}


void
on_button_accueil1_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion1;
windowconnexion1=lookup_widget(button,"window_connexion1");
gtk_widget_destroy(windowconnexion1);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_button_cnx1_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *CIN3, *password3, *windowconnexion1,*windowadmin ,*output;
char CIN4[50];
char password4[50];
int trouve;

CIN3 = lookup_widget(button, "entry_id1_cnx") ;
password3 = lookup_widget(button, "entry_pw1_cnx") ;
strcpy(CIN4, gtk_entry_get_text(GTK_ENTRY(CIN3))); 
strcpy(password4, gtk_entry_get_text(GTK_ENTRY(password3))); 
trouve=verif(CIN4,password4);

if(trouve==1)
{
windowconnexion1=lookup_widget(button,"window_connexion1");
gtk_widget_destroy(windowconnexion1);
windowadmin=create_window_admin();
gtk_widget_show(windowadmin);
}
else
{
output=lookup_widget(button,"label_erreur1");
gtk_label_set_text(GTK_LABEL(output), "UTILISATEUR INTROUVABLE");
}

}


void
on_button_decnx_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowadmin;
windowadmin=lookup_widget(button,"window_admin");
gtk_widget_destroy(windowadmin);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_radiobutton_homme1_aj_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}


void
on_radiobutton_femme1_aj_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=0;}
}


void
on_button_ajouter1_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur s;
GtkWidget *no,*pre,*cin,*jour,*mois,*annee,*adr,*numtel,*mail,*pw ,*genre,*choix, *windowajoutsucc;
no = lookup_widget(button,"entry_nom1_aj");
pre = lookup_widget(button,"entry_prenom1_aj");
cin = lookup_widget(button,"entry_id1_aj");
jour = lookup_widget(button,"spinbutton_jour1_aj");
mois = lookup_widget(button,"spinbutton_mois1_aj");
annee = lookup_widget(button,"spinbutton_annee1_aj");
adr = lookup_widget(button,"entry_adr1_aj");
numtel = lookup_widget(button,"entry_numtel1_aj");
mail = lookup_widget(button,"entry_mail1_aj");
pw = lookup_widget(button,"entry_pw1_aj");
choix = lookup_widget (button ,"combobox_choix1_aj");
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(no)));
strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(pre)));
strcpy(s.CIN,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(s.adresse,gtk_entry_get_text(GTK_ENTRY(adr)));
strcpy(s.numtelephone,gtk_entry_get_text(GTK_ENTRY(numtel)));
strcpy(s.mail,gtk_entry_get_text(GTK_ENTRY(mail)));
strcpy(s.password,gtk_entry_get_text(GTK_ENTRY(pw)));
strcpy(s.choix, gtk_combo_box_get_active_text(GTK_COMBO_BOX(choix)));
s.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
s.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
s.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
if(x==1 )
{strcpy(s.genre,"femme");} 
else
{strcpy(s.genre,"homme");} 
ajouterutilisateur(s);
x=0;

windowajoutsucc=create_window_ajout_succ();
gtk_widget_show (windowajoutsucc);
}



void
on_button_rechercher1_rech_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
char CIN5[50];
int k;

GtkWidget *idenr, *rech,*windowaffichagerecherche, *output,*windowadmin;
GtkWidget *tree;
GtkWidget *windowrechercher;
windowrechercher=lookup_widget(button,"window_rechercher");
windowadmin=create_window_admin();
idenr = lookup_widget(button,"entry_id1_rech");
strcpy(CIN5,gtk_entry_get_text(GTK_ENTRY(idenr)));
k=rechercherutilisateur(CIN5);

if (k==0)	
	{	

	output=lookup_widget(button,"label_erreur_rech");
	gtk_label_set_text(GTK_LABEL(output), "UTILISATEUR INTROUVABLE");
}

else
	{
	windowadmin=lookup_widget(button,"window_admin");
	gtk_widget_destroy(windowadmin);
	windowaffichagerecherche=create_window_affichage_recherche1();
	gtk_widget_show(windowaffichagerecherche);
	tree=lookup_widget(windowaffichagerecherche,"treeview_affichage_recherche1");

	affichageutilisateurrechercher(tree);


	}

}


void
on_button_supprimer1_supp_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
char CIN2[50];
FILE *f=fopen("utilisateur.txt","r");
utilisateur s;

GtkWidget *windowsup, *windoww, *iden,*output;
iden = lookup_widget(button,"entry_id1_supp");
output=lookup_widget(button,"label_erreur_supp");
windoww=create_window_confirmer_supp();
strcpy(CIN2,gtk_entry_get_text(GTK_ENTRY(iden)));
while(fscanf(f,"%s \n",s.CIN)!=EOF)
{
if (strcmp(CIN2,s.CIN)==0)
{
supprimerutilisateur(CIN2);

gtk_widget_show(windoww);
}

}
}
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* CIN;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* genre;
gchar* adresse;
gchar* numtelephone;
gchar* mail;
gchar* password;
gchar* choix;
utilisateur s;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* windowad,*tre,*CI,*no,*preno,*genr,*jou,*moi,*anne,*choi,*adress,*numtelephon,*mai,*passwor;

if (gtk_tree_model_get_iter(model, &iter,path))
{


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&CIN,3,&jour,4,&mois,5,&annee,6,&genre,7,&adresse,8,&numtelephone,9,&mail,10,&password,11,&choix,-1);



windowad=create_window_admin();
gtk_widget_hide(windowad);

gtk_widget_show(windowad);

no=lookup_widget(windowad,"entry_nom1_mod");
gtk_entry_set_text(GTK_ENTRY(no),nom);

preno=lookup_widget(windowad,"entry_prenom1_mod");
gtk_entry_set_text(GTK_ENTRY(preno),prenom);

CI=lookup_widget(windowad,"entry_id1_mod");
gtk_entry_set_text(GTK_ENTRY(CI),CIN);

jou=lookup_widget(windowad,"spinbutton_jour1_mod");
gtk_entry_set_text(GTK_ENTRY(jou),jour);

moi=lookup_widget(windowad,"spinbuttonmois1_mod");
gtk_entry_set_text(GTK_ENTRY(moi),mois);

anne=lookup_widget(windowad,"spinbutton_annee1_mod");
gtk_entry_set_text(GTK_ENTRY(anne),annee);

adress=lookup_widget(windowad,"entry_adr1_mod");
gtk_entry_set_text(GTK_ENTRY(adress),adresse);

numtelephon=lookup_widget(windowad,"entry_numtel1_mod");
gtk_entry_set_text(GTK_ENTRY(numtelephon),numtelephone);

mai=lookup_widget(windowad,"entry_mail1_mod");
gtk_entry_set_text(GTK_ENTRY(mai),mail);

passwor=lookup_widget(windowad,"entry_pw1_mod");
gtk_entry_set_text(GTK_ENTRY(passwor),password);


}

}


void
on_button_actualiser1_aff_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowadmin,*ibrahim;
windowadmin=lookup_widget(button,"window_admin");
ibrahim=create_window_admin();
gtk_widget_show(ibrahim);
gtk_widget_hide(windowadmin);
tree=lookup_widget(ibrahim,"treeview1");

affichageutilisateur(tree);

}


void
on_button_continue_aj_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajoutsucc;
windowajoutsucc=lookup_widget(button,"window_ajout_succ");
gtk_widget_destroy(windowajoutsucc);
}




void
on_button_annul_supp_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowadmin , *windowsupp; 
windowsupp=lookup_widget(button,"window_confirmer_supp");
gtk_widget_destroy(windowsupp);
}




void
on_button_inscri1_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *inscription1, *windowconnexion1;
windowconnexion1=lookup_widget(button,"window_connexion1");
gtk_widget_destroy(windowconnexion1);
inscription1=create_window_inscription1();
gtk_widget_show (inscription1);
}


void
on_button_insc1_insc_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f=NULL;
char nom1[50];
 char prenom1[50]; 
 char CIN1[50];
 char password1[50];
 char choix1[50];
GtkWidget *windowinscription1, *windowconnexion1,*no,*pre,*cin,*pw,*choix;
no = lookup_widget(button,"entry_nom1_insc");
pre = lookup_widget(button,"entry_prenom1_insc");
cin = lookup_widget(button,"entry_id1_insc");
pw = lookup_widget(button,"entry_pw1_insc");
choix = lookup_widget (button ,"combobox_choix1_insc");
strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(no)));
strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(pre)));
strcpy(CIN1,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(password1,gtk_entry_get_text(GTK_ENTRY(pw)));
strcpy(choix1, gtk_combo_box_get_active_text(GTK_COMBO_BOX(choix)));
f=fopen("users.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",nom1,prenom1,CIN1,password1,choix1);
fclose(f);
}

windowinscription1=lookup_widget(button,"window_inscription1");
gtk_widget_destroy(windowinscription1);
windowconnexion1=create_window_connexion1();
gtk_widget_show(windowconnexion1);
}


void
on_button_retour_insc_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowinscription1, *windowconnexion1;
windowinscription1=lookup_widget(button,"window_inscription1");
gtk_widget_destroy(windowinscription1);
windowconnexion1=create_window_connexion1();
gtk_widget_show(windowconnexion1);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
}

void
on_button_confirm1_modif_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_accueil2_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion2;
windowconnexion2=lookup_widget(button,"window_connexion2");
gtk_widget_destroy(windowconnexion2);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_button_cnx2_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *CIN3, *password3, *windowconnexion2,*windowadmin ,*output;
char CIN4[50];
char password4[50];
int trouve;

CIN3 = lookup_widget(button, "entry_id2_cnx") ;
password3 = lookup_widget(button, "entry_pw2_cnx") ;
strcpy(CIN4, gtk_entry_get_text(GTK_ENTRY(CIN3))); 
strcpy(password4, gtk_entry_get_text(GTK_ENTRY(password3))); 
trouve=verif(CIN4,password4);

if(trouve==1)
{
windowconnexion2=lookup_widget(button,"window_connexion2");
gtk_widget_destroy(windowconnexion2);
windowadmin=create_window_admin();
gtk_widget_show(windowadmin);
}
else
{
output=lookup_widget(button,"label_erreur_cnx2");
gtk_label_set_text(GTK_LABEL(output), "UTILISATEUR INTROUVABLE");
}

}
void
on_button_cnx3_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *CIN3, *password3, *windowconnexion3,*windowadmin ,*output;
char CIN4[50];
char password4[50];
int trouve;

CIN3 = lookup_widget(button, "entry_id3_cnx") ;
password3 = lookup_widget(button, "entry_pw3_cnx") ;
strcpy(CIN4, gtk_entry_get_text(GTK_ENTRY(CIN3))); 
strcpy(password4, gtk_entry_get_text(GTK_ENTRY(password3))); 
trouve=verif(CIN4,password4);

if(trouve==1)
{
windowconnexion3=lookup_widget(button,"window_connexion3");
gtk_widget_destroy(windowconnexion3);
windowadmin=create_window_admin();
gtk_widget_show(windowadmin);
}
else
{
output=lookup_widget(button,"label_erreur_cnx3");
gtk_label_set_text(GTK_LABEL(output), "UTILISATEUR INTROUVABLE");
}

}
void
on_button_accueil4_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion4;
windowconnexion4=lookup_widget(button,"window_connexion4");
gtk_widget_destroy(windowconnexion4);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_button_cnx4_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *CIN3, *password3, *windowconnexion4,*windowadmin ,*output;
char CIN4[50];
char password4[50];
int trouve;

CIN3 = lookup_widget(button, "entry_id4_cnx") ;
password3 = lookup_widget(button, "entry_pw4_cnx") ;
strcpy(CIN4, gtk_entry_get_text(GTK_ENTRY(CIN3))); 
strcpy(password4, gtk_entry_get_text(GTK_ENTRY(password3))); 
trouve=verif(CIN4,password4);

if(trouve==1)
{
windowconnexion4=lookup_widget(button,"window_connexion4");
gtk_widget_destroy(windowconnexion4);
windowadmin=create_window_admin();
gtk_widget_show(windowadmin);
}
else
{
output=lookup_widget(button,"label_erreur_cnx4");
gtk_label_set_text(GTK_LABEL(output), "UTILISATEUR INTROUVABLE");
}
}

void
on_button_accueil5_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion5;
windowconnexion5=lookup_widget(button,"window_connexion5");
gtk_widget_destroy(windowconnexion5);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_button_cnx5_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *CIN3, *password3, *windowconnexion5,*windowadmin ,*output;
char CIN4[50];
char password4[50];
int trouve;

CIN3 = lookup_widget(button, "entry_id5_cnx") ;
password3 = lookup_widget(button, "entry_pw5_cnx") ;
strcpy(CIN4, gtk_entry_get_text(GTK_ENTRY(CIN3))); 
strcpy(password4, gtk_entry_get_text(GTK_ENTRY(password3))); 
trouve=verif(CIN4,password4);

if(trouve==1)
{
windowconnexion5=lookup_widget(button,"window_connexion5");
gtk_widget_destroy(windowconnexion5);
windowadmin=create_window_admin();
gtk_widget_show(windowadmin);
}
else
{
output=lookup_widget(button,"label_erreur_cnx5");
gtk_label_set_text(GTK_LABEL(output), "UTILISATEUR INTROUVABLE");
}

}

void
on_button_cnx6_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *CIN3, *password3, *windowconnexion6,*windowadmin ,*output;
char CIN4[50];
char password4[50];
int trouve;

CIN3 = lookup_widget(button, "entry_id6_cnx") ;
password3 = lookup_widget(button, "entry_pw6_cnx") ;
strcpy(CIN4, gtk_entry_get_text(GTK_ENTRY(CIN3))); 
strcpy(password4, gtk_entry_get_text(GTK_ENTRY(password3))); 
trouve=verif(CIN4,password4);

if(trouve==1)
{
windowconnexion6=lookup_widget(button,"window_connexion6");
gtk_widget_destroy(windowconnexion6);
windowadmin=create_window_admin();
gtk_widget_show(windowadmin);
}
else
{
output=lookup_widget(button,"label_erreur_cnx6");
gtk_label_set_text(GTK_LABEL(output), "UTILISATEUR INTROUVABLE");
}
}

void
on_button_accueil6_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion6;
windowconnexion6=lookup_widget(button,"window_connexion6");
gtk_widget_destroy(windowconnexion6);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_button_accueil3_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowconnexion3;
windowconnexion3=lookup_widget(button,"window_connexion3");
gtk_widget_destroy(windowconnexion3);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_button_retour_admin_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowadmin, *windowaffichagerecherche;
windowaffichagerecherche=lookup_widget(button,"window_affichage_recherche1");
gtk_widget_destroy(windowaffichagerecherche);
windowadmin=create_window_admin();
gtk_widget_show(windowadmin);
}


void
on_radiobutton_homme1_mod_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=0;}
}


void
on_radiobutton_femme1_mod_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=1;}
}





void
on_button_brahim_modif_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur s1;
GtkWidget *no1,*pre1,*cin1,*jour1,*mois1,*annee1,*adr1,*numtel1,*mail1,*pw1 ,*genre1,*choix1, *windowmodifsucc;
no1 = lookup_widget(button,"entry_nom1_mod");
pre1 = lookup_widget(button,"entry_prenom1_mod");
cin1 = lookup_widget(button,"entry_id1_mod");
jour1 = lookup_widget(button,"spinbutton_jour1_mod");
mois1 = lookup_widget(button,"spinbuttonmois1_mod");
annee1 = lookup_widget(button,"spinbutton_annee1_mod");
adr1 = lookup_widget(button,"entry_adr1_mod");
numtel1 = lookup_widget(button,"entry_numtel1_mod");
mail1 = lookup_widget(button,"entry_mail1_mod");
pw1 = lookup_widget(button,"entry_pw1_mod");
choix1 = lookup_widget (button ,"combobox_choix1_mod");
strcpy(s1.nom,gtk_entry_get_text(GTK_ENTRY(no1)));
strcpy(s1.prenom,gtk_entry_get_text(GTK_ENTRY(pre1)));
strcpy(s1.CIN,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(s1.adresse,gtk_entry_get_text(GTK_ENTRY(adr1)));
strcpy(s1.numtelephone,gtk_entry_get_text(GTK_ENTRY(numtel1)));
strcpy(s1.mail,gtk_entry_get_text(GTK_ENTRY(mail1)));
strcpy(s1.password,gtk_entry_get_text(GTK_ENTRY(pw1)));
strcpy(s1.choix, gtk_combo_box_get_active_text(GTK_COMBO_BOX(choix1)));
s1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
s1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
s1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
if(y==1 )
{strcpy(s1.genre,"femme");} 
else
{strcpy(s1.genre,"homme");} 
modifierutilisateur(s1);
y=0;

windowmodifsucc=create_window_confirm_modif();
gtk_widget_show (windowmodifsucc);

}
void
on_button_continue_modif_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmodifsucc;
windowmodifsucc=lookup_widget(button,"window_confirm_succ");
gtk_widget_destroy(windowmodifsucc);
}


void
on_button_dashboard_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowdashboard;
windowbienvenue=lookup_widget(button,"window_bienvenue");
gtk_widget_destroy(windowbienvenue);
windowdashboard=create_window_dashboard11();
gtk_widget_show(windowdashboard);
}


void
on_button_debit_admin_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaffichdebit, *windowdashboard,*treee;
windowdashboard=lookup_widget(button,"window_dashboard11");
gtk_widget_destroy(windowdashboard);
windowaffichdebit=create_window_affichage_debit();
gtk_widget_show(windowaffichdebit);
treee=lookup_widget(windowaffichdebit,"treeview_debit");
affichedebit(treee);
}


void
on_button_accueil_dashboard_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowbienvenue, *windowdashboard;
windowdashboard=lookup_widget(button,"window_dashboard11");
gtk_widget_destroy(windowdashboard);
windowbienvenue=create_window_bienvenue();
gtk_widget_show(windowbienvenue);
}


void
on_button_retour_debit_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowdashboard, *windowaffichdebit;
windowaffichdebit=lookup_widget(button,"window_affichage_debit");
gtk_widget_destroy(windowaffichdebit);
windowdashboard=create_window_dashboard11();
gtk_widget_show(windowdashboard);
}


void
on_treeview_debit_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


#include <gtk/gtk.h>


void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_nutrition_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_foyer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_reclamation_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_alarme_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_accueil1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cnx1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_decnx_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme1_aj_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme1_aj_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_ajouter1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_femme1_mod_group_changed
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_homme1_mod_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_rechercher1_rech_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer1_supp_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_actualiser1_aff_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_continue_aj_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf1_supp_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_annul_supp_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_continue_modif_clicked       (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_inscri1_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme_insc1_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_insc1_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_ajouter_insc1_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_insc_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_insc1_insc_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_insc_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_confirm1_modif_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_accueil2_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cnx2_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cnx3_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_accueil4_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cnx4_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_accueil5_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cnx5_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_connexion6_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cnx6_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_accueil6_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_accueil3_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_admin_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme1_mod_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme1_mod_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_confirm1_modif_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_brahim_modif_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_dashboard_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_debit_admin_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_accueil_dashboard_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_debit_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_debit_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

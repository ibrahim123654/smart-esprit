#ifdef HAVE_CONFIG_H
#  include <config.h>
#include<stdio.h>
#include<string.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


reclamation h;
int x,y;

//liste hebergement.................................................................................

void
on_button_ajouter_rec_hbergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *ajouter11 ; 

ajouter11 = create_window_ajouter_reclamation();
gtk_widget_show(ajouter11);
}


void
on_button_Modifier_rec_hebergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier11 ; 

modifier11 = create_window_modifier_reclamation();
gtk_widget_show(modifier11);
}

void
on_button_supprimer_rec_hbergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer11 ; 

supprimer11 = create_window_supprimer_reclamation();
gtk_widget_show(supprimer11);
}


void
on_button_afficher_rec_hbergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowrec;
windowrec=lookup_widget(button,"window_liste_hebergement");
gtk_widget_destroy(windowrec);
windowrec=create_window_liste_hebergement();

tree=lookup_widget(windowrec,"treeview1");

afficher(tree);
gtk_widget_hide(windowrec);
gtk_widget_show(windowrec);
}
void
on_button_chercher_rec_hebergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *chercher11 ; 

chercher11 = create_window_chercher_reclamation();
gtk_widget_show(chercher11);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* titre;
gchar* id;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* genre;
gchar* email;
gchar* rec;

reclamation h;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* windowliste,*email12,*rec12,*jour12,*mois12,*annee12,*id12,*titre12,*genre12;

if (gtk_tree_model_get_iter(model, &iter,path))
{


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&titre,1,&email,2,&rec,3,&id,4,&genre,5,&jour,6,&mois,7,&annee, -1);



windowliste=create_window_modifier_reclamation();

gtk_widget_hide(windowliste);
gtk_widget_show(windowliste);

id12=lookup_widget(windowliste,"entry_id_modifier");
gtk_entry_set_text(GTK_ENTRY(id12),id);

jour12=lookup_widget(windowliste,"spinbutton2_jour");
gtk_entry_set_text(GTK_ENTRY(jour12),jour);


mois12=lookup_widget(windowliste,"spinbutton2_mois");
gtk_entry_set_text(GTK_ENTRY(mois12),mois);

annee12=lookup_widget(windowliste,"spinbutton2_annee");
gtk_entry_set_text(GTK_ENTRY(annee12),annee);

email12=lookup_widget(windowliste,"entry_email_modifier");
gtk_entry_set_text(GTK_ENTRY(email12),email);

rec12=lookup_widget(windowliste,"entry_reclamation_modifier");
gtk_entry_set_text(GTK_ENTRY(rec12),rec);



}
}
//ajouter............................................................................................
void
on_button_acceuil_ajouter_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *acceuil3 ;
acceuil3=lookup_widget(button,"window_ajouter_reclamation");
gtk_widget_destroy(acceuil3);
}

void
on_button_ajouter_ok_clicked           (GtkWidget      *button,
                                        gpointer         user_data)
{
 reclamation h;
GtkWidget *titre,*email,*rec,*id,*genre,*jour,*mois,*annee;
titre=lookup_widget(button, "comboboxentry_ajouter");
email=lookup_widget(button, "entry_ajouter_email");
rec=lookup_widget(button, "entry_ajouter_reclamation");
id=lookup_widget(button, "entry_ajouter_id");
jour=lookup_widget(button, "spinbutton_jour_ajouter");
mois=lookup_widget(button, "spinbutton_mois_ajouter");
annee=lookup_widget(button, "spinbutton_annee_ajouter");

strcpy(h.titre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(titre)));
strcpy(h.email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(h.rec,gtk_entry_get_text(GTK_ENTRY(rec)));
strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(id)));
h.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
h.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
h.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(x==1)
{
strcpy(h.genre,"femme");
}
else
{
strcpy(h.genre,"homme");
}
ajouter (h);
x=0; 
}

//supprimer.........................................................................
int confirmation=0;
int *r=&confirmation;
void
on_button_supprimer_supprimer_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
char titre3[50];
char id3[50];

GtkWidget *id4,*titre4,*confirmation11;
titre4=lookup_widget(button, "comboboxentry_supprimer");
id4 = lookup_widget(button,"entry_supprimer_id");
strcpy(titre3,gtk_combo_box_get_active_text(GTK_COMBO_BOX(titre4)));
strcpy(id3,gtk_entry_get_text(GTK_ENTRY(id4)));
if (confirmation==1)
supprimer(id3,titre3);
else
{
confirmation11=lookup_widget(button,"label_confirmation_supprimer");
gtk_label_set_text(GTK_LABEL(confirmation11),"la confirmation est obligatoire");
}
}

void
on_button_acceuil_supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *acceuil4 ;

acceuil4=lookup_widget(button,"window_supprimer_reclamation");
gtk_widget_destroy(acceuil4);
}
//modifier............................................................................................
void
on_button_modifier_modifier_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation h1;
GtkWidget *titre12,*email12,*rec12,*id12,*genre12,*jour12,*mois12,*annee12;
titre12=lookup_widget(button, "comboboxentry_modifier");
email12=lookup_widget(button, "entry_email_modifier");
rec12=lookup_widget(button, "entry_reclamation_modifier");
id12=lookup_widget(button, "entry_id_modifier");
jour12=lookup_widget(button, "spinbutton2_jour");
mois12=lookup_widget(button, "spinbutton2_mois");
annee12=lookup_widget(button, "spinbutton2_annee");

strcpy(h1.titre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(titre12)));
strcpy(h1.email,gtk_entry_get_text(GTK_ENTRY(email12)));
strcpy(h1.rec,gtk_entry_get_text(GTK_ENTRY(rec12)));
strcpy(h1.id,gtk_entry_get_text(GTK_ENTRY(id12)));
h1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour12));
h1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois12));
h1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee12));
if(y==1)
{
strcpy(h1.genre,"femme");
}
else
{
strcpy(h1.genre,"homme");
}
modifier (h1);
y=0;
}
void
on_button_acc_modifier_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *acceuil6 ;

acceuil6=lookup_widget(button,"window_modifier_reclamation");
gtk_widget_destroy(acceuil6);
}


////////////////////////chercher//////////////////////////////////////////////////////////////////////
void
on_button_acceuil_chercher_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *acceuil7 ;

acceuil7=lookup_widget(button,"window_chercher_reclamation");
gtk_widget_destroy(acceuil7);
}

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}




void
on_button_cher_chercher_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

char identir[50];
GtkWidget *idenr, *rech,*output,*cher11;
GtkWidget *tree;

int ce;
idenr = lookup_widget(button,"entry_chercher");
strcpy(identir,gtk_entry_get_text(GTK_ENTRY(idenr)));
ce=chercher(identir);
if (ce==0)
	{
	
	output=lookup_widget(button,"label_chercher");
	gtk_label_set_text(GTK_LABEL(output),"id n'existe pas");
	
	}
if (ce==1)	
	{	

rech=create_window_chercher_reclamation();
tree=lookup_widget(rech,"treeview3");

afficherchercher(tree);

gtk_widget_hide(rech);
gtk_widget_show(rech);
}		
}




void
on_button_plus_reclame_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
int x; 



GtkWidget *reclame11 ,*output11; 
x = plus_reclame();
reclame11 = create_window_plus_reclame();
gtk_widget_show(reclame11);
if (x==0)
{
output11=lookup_widget(reclame11,"label_plus_reclame");
gtk_label_set_text(GTK_LABEL(output11),"Restauration");
}
else if (x==1)
{
output11=lookup_widget(reclame11,"label_plus_reclame");
gtk_label_set_text(GTK_LABEL(output11),"Hebergement");
}
else 
{
output11=lookup_widget(reclame11,"label_plus_reclame");
gtk_label_set_text(GTK_LABEL(output11),"Egalite");
}
}

void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}
}


void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=0;}
}


void
on_radiobutton2_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=0;}
}


void
on_radiobutton2_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_checkbutton_confirmation_supp_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
*r=1;
else
*r=0;
}


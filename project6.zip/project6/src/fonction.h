#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include <gtk/gtk.h>
typedef struct {
int jour;
int mois;
int annee;
}DATE;
typedef struct {
char titre[50];
char email[50];
char rec[50];
char id[50];
char genre[50];
DATE date;
}reclamation;
///////////////////////////////
void ajouter(reclamation h);
///////////////////////////////
void modifier(reclamation h);
///////////////////////////////////////////
void supprimer(char id[],char titre[]);
//////////////////////////////////
void afficher(GtkWidget *liste);
////////////////////////////////////////////
void afficherchercher(GtkWidget *liste);
int chercher(char id[]);
int remplirtab (reclamation tab[],int nb);
////////////////////////////////
int plus_reclame();
#endif 

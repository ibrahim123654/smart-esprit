#include <gtk/gtk.h>


void
on_button_menu_heber_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_menu_restau_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_rec_hbergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Modifier_rec_hebergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_rec_hbergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_acceuil_rec_hebergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_rec_hebergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ajouter_rec_restauration_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_supprimer_restau_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_restau_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_acceuil_restau_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_restau_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ok_ajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_acceuil_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_acceuil_ajouter_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_ok_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_supprimer_supprimer_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_acceuil_supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_modifier_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_acceuil_modifier_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_rec_hbergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_chercher_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_acceuil_chercher_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_acc_modifier_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cher_chercher_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_plus_reclame_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_modifier_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_confirmation_supp_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
